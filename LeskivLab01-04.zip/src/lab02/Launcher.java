package lab02;

public class Launcher {

    public static void main(String[] args) {
        new ResizableFrame();
    }

}
