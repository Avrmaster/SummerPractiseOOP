package lab04;

public class DragLauncher {

    public static void main(String[] args) {
        new DragFrame();
    }

}
